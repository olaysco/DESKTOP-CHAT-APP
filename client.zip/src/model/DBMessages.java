/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import interfaces.Message;
import interfaces.MessageType;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author olayiwola
 */
public class DBMessages {
    
    String username = " ";
    Statement stmt;
    public DBMessages (String uname){
        Connection c = null;
        this.username = uname;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:messages.db");
            stmt = c.createStatement();
            boolean execute = stmt.execute("CREATE TABLE IF NOT EXISTS "+username+" ("
                    + "'Message' longblob NOT NULL"
                    + ");");
            stmt.close();
            c.close();
        } catch (ClassNotFoundException | SQLException e ) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage() );
            System .exit(0);
        }
        System.out.println("Opened database successfully");
    }
    
//    public static void main (String args[]) throws SQLException, Exception{
//        DBMessages db = new DBMessages("joel");
//        DBMessages dbf = new DBMessages("olay");
//        DBMessages dbg = new DBMessages("sam");
//        
//        Message msg = new Message();
//        msg.setName("Joel Dare");
//        msg.setMsg("Hello how are you");
//        msg.setType(MessageType.USER);
//        msg.setUsername("joel");
//        
//        Message msgd = new Message();
//        msgd.setName("Joel Dare");
//        msgd.setMsg("Hope you cool");
//        msgd.setType(MessageType.USER);
//        msgd.setUsername("joel");
//        
//        Message msgf = new Message();
//        msgf.setName("Olayiwola Odunsi");
//        msgf.setMsg("How va");
//        msgf.setType(MessageType.USER);
//        msgf.setUsername("olay");
//        
//        db.addMessages(msg);
//        dbf.addMessages(msg);
//        
//        db.addMessages(msgf);
//        dbf.addMessages(msgf);
//        
//        db.addMessages(msgd);
//        dbf.addMessages(msgd);
//        
//        
//        ArrayList<Message> ret = db.getMessages();
//         ArrayList<Message> retg = dbg.getMessages();
//        if(!ret.isEmpty()){
//            ret.forEach((message)->{System.out.println(message.getName()+" ");});
//        }
//        if(!retg.isEmpty()){
//            ret.forEach((message)->{System.out.println(message.getName()+" ");});
//        }
//    }
    
    public ArrayList<Message> getMessages() throws Exception{
        Connection con = null;
        Message messageObject = null;
        ResultSet rs = null;
        ByteArrayInputStream bos = null;
        ObjectInputStream ois = null;
        ArrayList<Message> messages = new ArrayList<>();
        try {
            con = DriverManager.getConnection("jdbc:sqlite:messages.db");
            PreparedStatement ps = null;
            String sql = "select * from "+username;
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                bos = new ByteArrayInputStream(rs.getBytes("message"));
                ois = new ObjectInputStream(bos);
                messageObject = (Message)ois.readObject();
                messages.add(messageObject);
            }
            
            
        } catch (Exception ex) {
            Logger.getLogger(DBMessages.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try{
            con.close();
            ois.close();
            }catch(NullPointerException e){
                System.out.println("Empty ");
            }
        }
        
        return messages;
    }
    
    public void addMessages(Object msg) throws SQLException{
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:sqlite:messages.db");
            PreparedStatement ps = null;
            
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(msg);
            oos.flush();
            oos.close();
            bos.close();
            byte[] data = bos.toByteArray();
            String sql = "insert into "+username+" (message) values (?)";
            ps = con.prepareStatement(sql);
            ps.setObject(1, data);
            ps.executeUpdate();
        } catch (Exception ex) {
            Logger.getLogger(DBMessages.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.close();
        }
        
    }
}
