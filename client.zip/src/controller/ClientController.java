/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javafx.stage.Stage;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.sql.Connection;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
/**
 *
 * @author olayiwola
 */
public class ClientController {
    private Main main;
    private Stage primaryStage;

    @FXML private JFXButton exitBtn1;
    @FXML private JFXTextField unameFieldReg;
    @FXML private JFXButton exitBtn;
    @FXML private JFXButton miniBtn1;
    @FXML private ImageView profileImage;
    @FXML private JFXTextField ipField;
    @FXML private JFXTextField portField;
    @FXML private JFXTextField ipField1;
    @FXML private JFXTextField portField1;
    @FXML private JFXTextField pwordFieldReg;
    @FXML private JFXTextField cpwordFieldReg;
    @FXML private JFXButton logBtn;
    @FXML private JFXButton regBtn;
    @FXML private JFXPasswordField passField;
    @FXML private GridPane loginPane;
    @FXML private JFXTextField lnameFieldReg;
    @FXML private JFXCheckBox editBox;
    @FXML private JFXCheckBox editBox1;
    @FXML private JFXButton miniBtn;
    @FXML private JFXTextField userField;
    @FXML private GridPane registerPane;
    @FXML private JFXTextField fnameFieldReg;
    @FXML private Button newUserBtn;
    @FXML private JFXButton backBtn;
    private String picture;
    String ip;
    String port;
    String username;
    ChatViewController cv;
    
    
    public void setMain(Main main, Stage primaryStage) {
        this.main = main;
        this.primaryStage = primaryStage;
        ipField.setDisable(true);
        portField.setDisable(true);
        ipField1.setDisable(true);
        portField1.setDisable(true);
//        passField.setText("riliwan");
//        userField.setText("olay");
    }
    
    public void handleLogin(ActionEvent event) {
        
        if(!userField.getText().isEmpty() && !passField.getText().isEmpty() && !ipField.getText().isEmpty() && !portField.getText().isEmpty()){
            username = userField.getText();
            String password = passField.getText();
            port = portField.getText();
            ip = ipField.getText();
            picture = "pic";
            Login logUser = new Login(ip, port, username, password, this);
            Thread logThread = new Thread(logUser);
            logThread.start();
        }
        else{
            showAlert();
        }
    }
    @FXML
    public void handleExitBtn(ActionEvent event) {
            Platform.exit();
            System.exit(0);
    }

    @FXML
    public void handleMiniBtn(ActionEvent event) {
        primaryStage.setIconified(true);
    }
    
    public void handleEditBox(ActionEvent event) {
        if(editBox.isSelected()){
            ipField.setDisable(false);
            portField.setDisable(false);
        }else{
             ipField.setDisable(true);
            portField.setDisable(true);
        }
        
        if(editBox1.isSelected()){
            ipField.setDisable(false);
            portField.setDisable(false);
        }else{
             ipField.setDisable(true);
            portField.setDisable(true);
        }
    }
    
    public void newUserBtnHandle(ActionEvent event){
        if(loginPane.isVisible() && !registerPane.isVisible()){
            loginPane.setVisible(false);
            registerPane.setVisible(true);
        }
    }
    
    public void handleRegisterBtn(ActionEvent event){
        if(!unameFieldReg.getText().isEmpty() && !pwordFieldReg.getText().isEmpty() && 
                !cpwordFieldReg.getText().isEmpty() && !lnameFieldReg.getText().isEmpty() && !fnameFieldReg.getText().isEmpty()){
                String username = unameFieldReg.getText();
                String password = pwordFieldReg.getText();
                String l_name = lnameFieldReg.getText();
                String f_name = fnameFieldReg.getText();
                String port = portField.getText();
                String ip = ipField.getText();
            if(cpwordFieldReg.getText().equals(pwordFieldReg.getText())){
                Register reg = new Register(ip, port, username, password, l_name, f_name, this);
                Thread regThread = new Thread(reg);
                regThread.setDaemon(true);
                regThread.start();
            }else{
                showErrorAlert("ensure the password is same as password confirmed");
            }
            
        }else{
            showAlert();
        }
        
    }
    
    private boolean checkUserDetails(String username, String password) {
        picture = "olaypic";
       return (username.equals("olay"))&&(password.equals("riliwan"));
    }

    private void showAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setContentText("please ensure all fields are set");
        alert.showAndWait();
    }
    
    public void showSuccessAlert(String msg) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setContentText(msg);
            alert.setHeaderText("Information");
            alert.showAndWait();
       });
        
    }
    
    public void showErrorAlert(String msg) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText(msg);
            alert.showAndWait();
        });
    }
    
    public void showLoginPane(){
        Platform.runLater(() -> {
            if(!loginPane.isVisible() && registerPane.isVisible()){
                registerPane.setVisible(false);
                loginPane.setVisible(true);
            }
        });
    }
    
    public void handleBackBtn(ActionEvent event){
        Platform.runLater(() -> {
            showLoginPane();
        });
    }
    
    public void loginSuccessful(String name){
        Platform.runLater(() -> {
            primaryStage.close();
            cv = main.openChatView();
            ServerConnect serverconnect = new ServerConnect(ip, port, username, name, cv);
            cv.serverInstance = serverconnect;
            Thread th = new Thread(serverconnect);
            System.out.println("login ");
            th.start();
        });
    }
}
