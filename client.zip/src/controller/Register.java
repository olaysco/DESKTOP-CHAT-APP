/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import interfaces.Message;
import static interfaces.MessageType.REGISTER;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author olayiwola
 */
public class Register implements Runnable{
    private final String ip;
    private final String l_name;
    private final String f_name;
    private final String username;
    private final int port;
    private final String password;
    public Map<String,String> registerDetails = new HashMap<>();
    private final ClientController clientcontroller;
    
    public Register(String ip, String port, String username, String password, String l_name, String f_name, ClientController cc){
        this.ip = ip;
        this.port = Integer.parseInt(port);
        this.username = username;
        this.password = password;
        this.f_name = f_name;
        this.l_name = l_name;
        this.clientcontroller = cc;
    }


    @Override
    public void run() {
        registerClient();
    }

    private void registerClient() {
        try {
            Socket sc = new Socket(ip, port);
            ObjectOutputStream oos = new ObjectOutputStream(sc.getOutputStream());
            Message msg = new Message();
            msg.setType(REGISTER);
            registerDetails.put("username", username);
            registerDetails.put("password", password);
            registerDetails.put("f_name", f_name);
            registerDetails.put("l_name", l_name);
            msg.setRegisterDetails(registerDetails);
            oos.writeObject(msg);
            ObjectInputStream ois = new ObjectInputStream(sc.getInputStream());
            Message in =(Message) ois.readObject();
            if(in.getRegisterSuccess()){
                System.out.println("Registeration Successfull");
                clientcontroller.showSuccessAlert("Registeration Successfull");
                clientcontroller.showLoginPane();
            }
            else{
                System.out.println(in.getMsg());
                clientcontroller.showErrorAlert(in.getMsg());
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
