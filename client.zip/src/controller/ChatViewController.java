/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javafx.stage.Stage;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.effects.JFXDepthManager;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;
import com.messages.bubble.BubbleSpec;
import com.messages.bubble.BubbledLabel;

import interfaces.Message;
import interfaces.MessageType;
import interfaces.User;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.DBMessages;

/**
 *
 * @author olayiwola
 */
public class ChatViewController implements Initializable{
    
    @FXML private Button onlineCount;
    @FXML private JFXListView<User> onlineUserList;
    @FXML private JFXListView<HBox> msgDisplayList;
    @FXML private JFXComboBox<String> comboStatus;
    @FXML private Label labelUserName;
    @FXML private JFXButton btnFile;
    @FXML private ImageView profileImg;
    @FXML private JFXTextArea msgTextArea;
    @FXML private JFXButton btnSend;
    @FXML private JFXButton btnAudio;
    @FXML private BorderPane borderPane;
    @FXML private BorderPane titleBorderPane;
    @FXML private Label ipLabel;
    @FXML private ScrollPane chatScrollpane;
    @FXML private VBox chatVbox;
    @FXML private Text welcomeText;
    @FXML private HBox buttonHBox;
    @FXML private Pane titlePane;
    @FXML private AnchorPane anchorPane;
    @FXML private JFXHamburger hamburger;
    @FXML private JFXDrawer drawer;
    
    Main main;
    Stage primaryStage;
    Stage logStage;
    
    private double xOffset;
    private double yOffset;
    private HashMap<String, JFXListView<HBox>> chatPaneCollection = new HashMap<>();
    private String username;
    private boolean isClickedAUser = false;
    private String selectedUser;
    JFXDepthManager depth;
    ServerConnect serverInstance;
    

    
    
    public void setMain(Main aThis, Stage primaryStage, Stage logStage) {
        this.main = aThis;
        this.primaryStage = primaryStage;
        this.logStage = logStage;
        comboStatus.getItems().add("Online");
        comboStatus.getItems().add("Away");
        comboStatus.getItems().add("Busy");
        comboStatus.getSelectionModel().selectedItemProperty().addListener((v, oldValue,newValue)->{
            changeStatus(newValue);
        });
        labelUserName.setText("");
        onlineUserList.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends User> v, User oldValue, User newValue) -> {
            userSelected(newValue);
        }); 
    }
    
    
   @Override public void initialize(URL location, ResourceBundle resources) {
        
        anchorPane.setOnMousePressed(event -> {
            xOffset = primaryStage.getX() - event.getScreenX();
            yOffset = primaryStage.getY() - event.getScreenY();
            anchorPane.setCursor(Cursor.CLOSED_HAND);
        });

        anchorPane.setOnMouseDragged(event -> {
            primaryStage.setX(event.getScreenX() + xOffset);
            primaryStage.setY(event.getScreenY() + yOffset);
        });

        anchorPane.setOnMouseReleased(event -> {
            anchorPane.setCursor(Cursor.DEFAULT);
        });
        
        AnchorPane.setRightAnchor(drawer, 960.0);
        
        try {
            FXMLLoader loader = new FXMLLoader(ChatViewController.class.getResource("/view/SidePanel.fxml"));
            VBox stackPane = loader.load();
            SidePanelController spc = loader.getController();
            spc.setMain(this);
            depth = new JFXDepthManager();
            depth.setDepth(stackPane, 1);
            drawer.setSidePane(stackPane);
        } catch (IOException ex) {
            Logger.getLogger(ChatViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HamburgerBackArrowBasicTransition burgerTask = new HamburgerBackArrowBasicTransition(hamburger);
        burgerTask.setRate(-1);
        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED, (e)-> {
            burgerTask.setRate(burgerTask.getRate() * -1);
            burgerTask.play();
            if(drawer.isShown()){
                AnchorPane.setRightAnchor(drawer, 960.0);
                drawer.close();
            }else{
                drawer.open();
                AnchorPane.setRightAnchor(drawer, 660.0);
            }
        });
    }
    
   public void instanceTest(){
       System.out.println(username+" is the username");
   }
   
    public void setName(String name){
        Platform.runLater(()->labelUserName.setText(name));
    }
    
    public void setIp(String ip){
        ipLabel.setText(ip);
    }
    
    @FXML public void handleBtnSend(ActionEvent event) {
        Platform.runLater(() ->{ 
        if(!msgTextArea.getText().isEmpty()){
            String msgText = msgTextArea.getText();
            Message msg = new Message();
            msg.setName(labelUserName.getText());
            msg.setMsg(msgText);
            msg.setType(MessageType.USER);
            msg.setUsername(username);
            msg.setDestination(selectedUser);
            addToChat(msg, chatPaneCollection.get(selectedUser) );
            serverInstance.sendTextMessage(msg);
            
        }
        });
    }

    @FXML public void handleBtnFile(ActionEvent event) {

    }

    @FXML public void handleBtnAudio(ActionEvent event) {

    }
    
    @FXML public void handleMinimize(ActionEvent event) {
        primaryStage.setIconified(true);
    }

    @FXML public void handleExit(ActionEvent event) {
        Message msg = new Message();
        msg.setName(labelUserName.getText());
        msg.setType(MessageType.DISCONNECTED);
        msg.setUsername(username);
        serverInstance.sendTextMessage(msg);
        Platform.exit();
        System.exit(0);
    }

    public void setOnlineCount(String count){
       Platform.runLater(()->onlineCount.setText(count));
    }
    
    

    public void addToChat(Message msg) {
        
        System.out.println(chatPaneCollection.get(msg.getUsername()).getHeight());
        Task<HBox> othersMessages = new Task<HBox>() {
            @Override
            public HBox call() throws Exception {
                Image image = new Image(getClass().getClassLoader().getResource("view/" + "pic" + ".jpg").toString());
                ImageView profileImage = new ImageView(image);
                profileImage.setFitHeight(32);
                profileImage.setFitWidth(32);
                BubbledLabel bl6 = new BubbledLabel();
                
                if (msg.getType() == MessageType.VOICE){
                    ImageView imageview = new ImageView(new Image(getClass().getClassLoader().getResource("view/sound.png").toString()));
                    bl6.setGraphic(imageview);
                    bl6.setText("Sent a voice message!");
                    
                }else {
                    bl6.setText(msg.getName() + ": " + msg.getMsg());
                }
                bl6.setBackground(new Background(new BackgroundFill(Color.DARKGRAY,null, null)));
                HBox x = new HBox();
                bl6.setBubbleSpec(BubbleSpec.FACE_LEFT_CENTER);
                x.getChildren().addAll(profileImage, bl6);
//                logger.debug("ONLINE USERS: " + Integer.toString(msg.getUserlist().size()));
//                setOnlineCount(Integer.toString(msg.getOnlineCount()));
                return x;
            }
        };

        othersMessages.setOnSucceeded(event -> {
            chatPaneCollection.get(msg.getUsername()).getItems().add(othersMessages.getValue());
        });
        
        Thread t = new Thread(othersMessages);
        t.setDaemon(true);
        t.start();
    }
    
    
    
    public void addToChat(Message msg, JFXListView<HBox> customPane) {
        Task<HBox> othersMessages = new Task<HBox>() {
            @Override
            public HBox call() throws Exception {
                Image image = new Image(getClass().getClassLoader().getResource("view/" + "pic" + ".jpg").toString());
                ImageView profileImage = new ImageView(image);
                profileImage.setFitHeight(32);
                profileImage.setFitWidth(32);
                BubbledLabel bl6 = new BubbledLabel();
                if (msg.getType() == MessageType.VOICE){
                    ImageView imageview = new ImageView(new Image(getClass().getClassLoader().getResource("view/sound.png").toString()));
                    bl6.setGraphic(imageview);
                    bl6.setText("Sent a voice message!");
                    
                }else {
                    bl6.setText(msg.getName() + ": " + msg.getMsg());
                }
                bl6.setBackground(new Background(new BackgroundFill(Color.GRAY,null, null)));
                HBox x = new HBox();
                bl6.setBubbleSpec(BubbleSpec.FACE_LEFT_CENTER);
                x.getChildren().addAll(profileImage, bl6);
//                logger.debug("ONLINE USERS: " + Integer.toString(msg.getUserlist().size()));
//                setOnlineCount(Integer.toString(msg.getOnlineCount()));
                return x;
            }
        };

        othersMessages.setOnSucceeded(event -> {
            customPane.getItems().add(othersMessages.getValue());
        });

        Task<HBox> yourMessages = new Task<HBox>() {
            @Override
            public HBox call() throws Exception {
                Image image = profileImg.getImage();
                ImageView profileImage = new ImageView(image);
                profileImage.setFitHeight(32);
                profileImage.setFitWidth(32);

                BubbledLabel bl6 = new BubbledLabel();
                if (msg.getType() == MessageType.VOICE){
                    bl6.setGraphic(new ImageView(new Image(getClass().getClassLoader().getResource("view/sound.png").toString())));
                    bl6.setText("Sent a voice message!");
                    
                }else {
                    bl6.setText(msg.getMsg());
                }
                bl6.setBackground(new Background(new BackgroundFill(Color.web("#1ecbfd"),
                        null, null)));
                HBox x = new HBox();
                x.setMaxWidth( 700);
                x.setAlignment(Pos.TOP_RIGHT);
                bl6.setBubbleSpec(BubbleSpec.FACE_RIGHT_CENTER);
                x.getChildren().addAll(bl6, profileImage);

//                setOnlineCount(Integer.toString(msg.getOnlineCount()));
                return x;
            }
        };
        yourMessages.setOnSucceeded(event -> {
            customPane.getItems().add(yourMessages.getValue());
        });

        
        if (msg.getUsername().equals(username)) {
            Thread t2 = new Thread(yourMessages);
            t2.setDaemon(true);
            t2.start();
            System.out.println(msg.getMsg());
        } else {
            Thread t = new Thread(othersMessages);
            t.setDaemon(true);
            t.start();
            System.out.println(msg.getMsg());
        }
        
    }
    
    
    

 

    public void addAsServer(Message message) {
        Task<HBox> task = new Task<HBox>() {
            @Override
            public HBox call() throws Exception {
                BubbledLabel bl6 = new BubbledLabel();
                bl6.setText(message.getMsg());
                bl6.setBackground(new Background(new BackgroundFill(Color.ALICEBLUE,
                        null, null)));
                HBox x = new HBox();
                bl6.setBubbleSpec(BubbleSpec.FACE_BOTTOM);
                x.setAlignment(Pos.CENTER);
                x.getChildren().addAll(bl6);
                return x;
            }
        };
        task.setOnSucceeded(event -> {
            msgDisplayList.getItems().add(task.getValue());
        });

        Thread t = new Thread(task);
        t.setDaemon(true);
        t.start();
    }

    public void setUserList(Message message, String username) {
        Platform.runLater(()->{ 
           
            message.getUsers().removeIf((User t) -> t.getUsername().equals(username));
            ObservableList<User> users = FXCollections.observableList(message.getUsers());
            onlineUserList.setItems(users);
            onlineUserList.setCellFactory(new UserListDisplay());
            setOnlineCount(String.valueOf(message.getUserlist().size() - 1));
            
            initChatPaneForUser(message.getUsers());
        
        });
    }
   

    private void changeStatus(String newStatus) {
        System.out.println("Status changed to "+newStatus);
    }

    private void userSelected(User user) {
        System.out.println("this user has been selected "+user.getUsername());
        if(!isClickedAUser){
            isClickedAUser = true;
            borderPane.setRight(null);
            buttonHBox.setVisible(true);
            chatVbox.setVisible(true);
        }
        selectedUser = user.getUsername();
        chatScrollpane.setContent(chatPaneCollection.getOrDefault(user.getUsername(), msgDisplayList));
        
    }

    public JFXListView<HBox> JCustomChatPane(String uname){
        final JFXListView<HBox> chatPane = new JFXListView<>();
        chatPane.setPrefWidth(720);
        chatPane.setPrefHeight(500);
        chatPane.setVisible(true);
        try {
            DBMessages db = new DBMessages(uname);
            ArrayList<Message> dbMessagesStored = db.getMessages();
            if(!dbMessagesStored.isEmpty()){
                dbMessagesStored.forEach((Message msg)->{
                    addToChat(msg, chatPane);
                    
                });
            }
        }catch(NullPointerException e){ 
            System.out.println("Chat empty");
        }
        catch (Exception ex) {
            Logger.getLogger(ChatViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return chatPane;
    }
    
    private void initChatPaneForUser(ArrayList<User> users) {
        Platform.runLater(()->{
            users.forEach((User us) -> {
                chatPaneCollection.putIfAbsent(us.getUsername(), JCustomChatPane(us.getUsername()));
            });
        });
    }

    public void setUserame(String uname) {
        Platform.runLater(()->this.username = uname);
    }

    public void logoutUser(){
        Platform.runLater(() ->{ 
            Message msg = new Message();
            msg.setName(labelUserName.getText());
            msg.setType(MessageType.DISCONNECTED);
            msg.setUsername(username);
            serverInstance.sendTextMessage(msg);
            primaryStage.close();
            logStage.show();
        });
    }
}
