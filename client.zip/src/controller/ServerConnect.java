/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import interfaces.Message;
import interfaces.MessageType;
import static interfaces.MessageType.CONNECTED;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author olayiwola
 */
public class ServerConnect implements Runnable{

    
    int port;
    ObjectInputStream ois;
    ObjectOutputStream oos;
    String name;
    String username;
    String password;
    String ip;
    String picture;
    Socket socket;
    private static final String HASCONNECTED = "has connected";
    private final  ChatViewController chatController;
    
    public ServerConnect(String ip, String port, String username, String name, ChatViewController chatController) {
        this.port = Integer.parseInt(port);
        this.ip = ip;
        this.username = username;
        this.chatController = chatController;
        this.name = name;
    }
    
    
    
    @Override    
   public void run() {
       connectSocket();  
    }  

  
    

    private void connectSocket() {
        try{
           socket = new Socket(ip, this.port);
           System.out.println("server reached");
           oos = new ObjectOutputStream(socket.getOutputStream());
           Message msg = new Message();
           msg.setUsername(username);
           msg.setName(name);
           msg.setIp(socket.getInetAddress());
           msg.setType(CONNECTED);
           msg.setMsg(HASCONNECTED);
           msg.setPicture(picture);
           oos.writeObject(msg);
           System.out.println("ghvvvyj ");
           ois = new ObjectInputStream(socket.getInputStream());
           Message in =(Message) ois.readObject();
           System.out.println("online user "+in.getOnlineCount());
           System.out.println("user status "+in.getStatus());
           chatController.setName(name);
           chatController.setUserame(username);
           chatController.setOnlineCount(Integer.toString(in.getOnlineCount() - 1));
          
           chatController.setUserList(in, username);
           
        
       
        while(socket.isConnected()){
          try{
              Message message = null;

                message =(Message) ois.readObject();

                if (message != null) {
                    switch (message.getType()) {
                        case USER:
                            chatController.addToChat(message);
                            System.out.println("new msg from "+msg.getUsername());
                            break;
    //                    case VOICE:
    //                        chatController.addToChat(message);
    //                        break;
    //                    case NOTIFICATION:
    //                        chatController.newUserNotification(message);
    //                        break;
                        case SERVER:
                            chatController.addAsServer(message);
                            break;
                        case CONNECTED:
                            chatController.setUserList(message, username);
                            System.out.println("New user connected");
                            break;
                        case DISCONNECTED:
                            chatController.setUserList(message, username);
                            break;
                        case STATUS:
                            chatController.setUserList(message, username);
                            break;
                    }
                }
          }
            catch (Exception e){
              System.out.println("Error "+e.getCause());
        }
            
          } 
        }catch(IOException | ClassNotFoundException e){
            e.printStackTrace();
        }
    }
  
     public static void sendVoiceMessage(byte[] toByteArray) {
     
     }   
        
    public static void endMySession(Message msg){
        
    }   

    public void sendTextMessage(Message msg) {
        try {
            oos.writeObject(msg);
            
        } catch (IOException ex) {
            Logger.getLogger(ServerConnect.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
    

    
