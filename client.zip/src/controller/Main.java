package controller;


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author olayiwola
 */
public class Main extends Application{

    Stage primaryStage;
    Stage chatStage = new Stage();
    ChatViewController cv;
    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        openWindow();
        //openChatView();
    }

    public void openWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/LoginView.fxml"));
            AnchorPane pane = loader.load();
            ClientController cc = loader.getController();
            cc.setMain(this, primaryStage);
            
            Scene scene = new Scene(pane);
            scene.getStylesheets().add(getClass().getResource("/view/style.css").toExternalForm());
            primaryStage.initStyle(StageStyle.UNDECORATED);
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();
            primaryStage.setOnCloseRequest(e -> Platform.exit());
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
     public ChatViewController openChatView() {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/chatWindowView.fxml"));
            
            AnchorPane pane = loader.load();
            cv = loader.getController();
            cv.setMain(this, chatStage, primaryStage);
            
            Scene scene = new Scene(pane);
            scene.getStylesheets().add(getClass().getResource("/view/style.css").toExternalForm());
            
            chatStage.initStyle(StageStyle.UNDECORATED);
            chatStage.setScene(scene);
            chatStage.setResizable(false);
            chatStage.show();
            chatStage.setOnCloseRequest(e -> Platform.exit());
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cv;
        
    }
    
    public static void main (String args[]){
        launch(args);
    }
    
    
}
