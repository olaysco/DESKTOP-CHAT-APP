/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

/**
 *
 * @author olayiwola
 */
public class Test extends ClientController implements Runnable{
    private static ClientController client;

    public Test(ClientController cc) {
        Test.client = cc;
    }
    

    @Override
    public void run() {
        client.showSuccessAlert("error alert");
    }
}
