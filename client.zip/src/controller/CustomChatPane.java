/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import com.jfoenix.controls.JFXListView;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;

/**
 *
 * @author olayiwola
 */
public class CustomChatPane{
    JFXListView<HBox> chatPane;
    public CustomChatPane(){
        chatPane = new JFXListView<>();
        chatPane.setPrefWidth(736);
        chatPane.setPrefHeight(500);
    }
    
}
