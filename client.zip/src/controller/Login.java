/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import interfaces.Message;
import static interfaces.MessageType.AUTHENTICATE;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author olayiwola
 */
public class Login implements Runnable{
    private final String ip;
    private final String username;
    private final int port;
    private final String password;
    public Map<String,String> loginDetails = new HashMap<>();
    private final ClientController clientcontroller;
    
    public Login(String ip, String port, String username, String password, ClientController cc){
        this.ip = ip;
        this.port = Integer.parseInt(port);
        this.username = username;
        this.password = password;
        this.clientcontroller = cc;
    }

    @Override
    public void run() {
        try {
            Socket sc = new Socket(ip, port);
            ObjectOutputStream oos = new ObjectOutputStream(sc.getOutputStream());
            Message msg = new Message();
            msg.setType(AUTHENTICATE);
            loginDetails.put("username", username);
            loginDetails.put("password", password);
            System.out.println(username +"\n"+ password);
            msg.setLoginDetails(loginDetails);
            oos.writeObject(msg);
            ObjectInputStream ois = new ObjectInputStream(sc.getInputStream());
            Message in =(Message) ois.readObject();
            if(in.getLoginSuccess()){
                System.out.println("login Successfull");
                clientcontroller.showSuccessAlert("login Successfull");
                clientcontroller.loginSuccessful(in.getName());
            }
            else{
                System.out.println(in.getMsg());
                clientcontroller.showErrorAlert(in.getMsg());
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
    
