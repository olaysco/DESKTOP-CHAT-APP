/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.TitledPane;

/**
 * FXML Controller class
 *
 * @author olayiwola
 */
public class SidePanelController implements Initializable {
    @FXML private JFXTextField lnameField;
    @FXML private JFXTextField fnameField;
    @FXML private JFXButton changeNameBtn;
    @FXML private JFXTextField cpwordField;
    @FXML private JFXTextField pwordField;
    @FXML private JFXButton changePasswordBtn;
    @FXML private JFXButton logoutBtn;
    @FXML private Accordion accordion;
    @FXML private TitledPane nameAccordion;
    private ChatViewController chatController;
    /**
     * Initializes the controller class.
     */
    
    /**
     * Initializes the controller class.
     * @param cvc
     */
    public void setMain(ChatViewController cvc){
        chatController = cvc;
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        accordion.setExpandedPane(nameAccordion);
        // TODO
    }    

    @FXML
    private void handleNameBtn(ActionEvent event) {
        System.out.println("name change action");
        chatController.instanceTest();
    }

    @FXML
    private void handlePasswordBtn(ActionEvent event) {
        System.out.println("password change action");
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        System.out.println("logout action");
        Platform.runLater(()->{
            chatController.logoutUser();
        });
    }
    
}
