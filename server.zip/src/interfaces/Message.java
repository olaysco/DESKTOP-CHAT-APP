package interfaces;

import java.io.Serializable;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Message implements Serializable {

    private String name;
    private String username;
    private MessageType type;
    private String destination;
    private String msg;
    private int count;
    private ArrayList<User> list;
    private ArrayList<User> users;
    private InetAddress ip;
    private Status status;
    private byte[] voiceMsg;
    private String picture;
    private Map<String,String> registerDetails = new HashMap<>();
    private Map<String,String> loginDetails = new HashMap<>();
    private Boolean registerSuccess;
    private Boolean loginSuccess;

    public byte[] getVoiceMsg() {
        return voiceMsg;
    }

    public String getPicture() {
        return picture;
    }

    

    public Message() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMsg() {

        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public MessageType getType() {
        return type;
    }

    public void setType(MessageType type) {
        this.type = type;
    }

    public ArrayList<User> getUserlist() {
        return list;
    }

    public void setUserlist(HashMap<String, User> userList) {
        this.list = new ArrayList<>(userList.values());
    }

    public void setOnlineCount(int count){
        this.count = count;
    }

    public int getOnlineCount(){
        return this.count;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }


    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }

    public void setVoiceMsg(byte[] voiceMsg) {
        this.voiceMsg = voiceMsg;
    }

    /**
     * @return the ip
     */
    public InetAddress getIp() {
        return ip;
    }

    /**
     * @param ip the ip to set
     */
    public void setIp(InetAddress ip) {
        this.ip = ip;
    }

    /**
     * @return the registerDetails
     */
    public Map<String,String> getRegisterDetails() {
        return registerDetails;
    }

    /**
     * @param registerDetails the registerDetails to set
     */
    public void setRegisterDetails(Map<String,String> registerDetails) {
        this.registerDetails = registerDetails;
    }

    /**
     * @return the loginDetails
     */
    public Map<String,String> getLoginDetails() {
        return loginDetails;
    }

    /**
     * @param loginDetails the loginDetails to set
     */
    public void setLoginDetails(Map<String,String> loginDetails) {
        this.loginDetails = loginDetails;
    }

    /**
     * @return the registerSuccess
     */
    public Boolean getRegisterSuccess() {
        return registerSuccess;
    }

    /**
     * @return the loginSuccess
     */
    public Boolean getLoginSuccess() {
        return loginSuccess;
    }

    /**
     * @param registerSuccess the registerSuccess to set
     */
    public void setRegisterSuccess(Boolean registerSuccess) {
        this.registerSuccess = registerSuccess;
    }

    /**
     * @param loginSuccess the loginSuccess to set
     */
    public void setLoginSuccess(Boolean loginSuccess) {
        this.loginSuccess = loginSuccess;
    }

    /**
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * @param destination the destination to set
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }
    
    
}
