package interfaces;

/**
 
 */
public enum Status {
    ONLINE, AWAY, BUSY
}
