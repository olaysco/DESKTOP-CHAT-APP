/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author olayiwola
 */
public class Main extends Application{
    
    private Stage primaryStage;
    ServerController servercontroller;

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        mainWindow();
    }

    public void mainWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/FXMLServer.fxml"));
            AnchorPane pane = loader.load();
            servercontroller = loader.getController();
            servercontroller.setMain(this, primaryStage);
            
            Scene scene = new Scene(pane);
            scene.getStylesheets().add(getClass().getResource("/view/style.css").toExternalForm());
            
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();
            
            primaryStage.setOnCloseRequest(e ->{ Platform.exit(); System.exit(0);});
            
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main (String args[]){
        launch(args);
    }

    @Override
    public void stop() throws Exception {
        super.stop(); 
        
        servercontroller.onExit();
        
    }
    
    
    
}
