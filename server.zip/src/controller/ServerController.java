/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.UnknownHostException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 *
 * @author olayiwola
 */
public class ServerController {
    
    @FXML Label listenLabel;
    @FXML ImageView onlineIcon;
    @FXML ImageView offlineIcon;
    @FXML Button startBtn;
    Server server;
    Thread thread;
    
    
    private Main main;

    public void setMain(Main main, Stage stage) {
        this.main = main;
        startBtn.setFocusTraversable(false);
    }
    
    public void handleStartBtn() throws UnknownHostException{
        server = new Server();
        thread = new Thread(server);
        thread.start();
        
            String text = "listening on IP :"+server.getIP()+"PORT: "+server.getPORT();
            listenLabel.setText(text);
            offlineIcon.setVisible(false);
            onlineIcon.setVisible(true);
            startBtn.setDisable(true);
            startBtn.setText("Started");
        
    }
    
    public void handleSusspendBtn() throws UnknownHostException{
        
    } 

    public void onExit() {
        server.endSession();
    }
    
}
