/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import interfaces.Message;
import interfaces.Message;
import interfaces.MessageType;
import interfaces.Status;
import interfaces.User;
import java.io.IOException;
import java.io.InputStream;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author olayiwola
 */
public class Server implements Runnable{
    
    private  final int PORT = 45405;
    private final InetAddress IP; 
    private  boolean isOn = false;
    Connection c;
    Statement stmt;
    Boolean isRegOk = false;
    private static final HashMap<String, User> names = new HashMap<>();
    private static HashSet<ObjectOutputStream> writers = new HashSet<>();
    private static ArrayList<User> online_users = new ArrayList<>();
    private static ArrayList<InetAddress> connected_ips = new ArrayList<>();
    
    
    
    public Server() throws UnknownHostException{
        this.IP = InetAddress.getLocalHost();
        
    }

    @Override
    public void run() {
        try {
            ServerSocket ss = new ServerSocket(getPORT());
            
            
            while(true){
      
               Socket socket = ss.accept();
                ServerThread <Socket>st = new ServerThread(socket);
                Thread th = new Thread(st);
                th.start();
               
            }
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * @return the PORT
     */
    public int getPORT() {
        return PORT;
    }

    /**
     * @return the IP
     */
    public InetAddress getIP() {
        return IP;
    }

    /**
     * @return the isOn
     */
    public boolean isIsOn() {
        return isOn;
    }

   

    /**
     * @param isOn the isOn to set
     */
    public void setIsOn(boolean isOn) {
        this.isOn = isOn;
    }
    
    public void endSession(){
        
//       server.closeSocket();
    }
    
    class InnerServerThread implements Runnable{
        
        Socket socket;
        String name = null;
        User user = null;
        
        public InnerServerThread(Socket st){
            socket = st;
            System.out.print("Enter thread constructor ");
        }
        
        @Override
        public void run(){
            
            try(InputStream is = socket.getInputStream();
                ObjectInputStream input = new ObjectInputStream(is);
                OutputStream os = socket.getOutputStream();
                ObjectOutputStream output = new ObjectOutputStream(os)) {
                 System.out.print("new thread RUN  started");
               
                System.out.print("new thread  started");
                Message firstMessage = (Message)input.readObject();
                checkConnecedIP(firstMessage);
                sendUserList();
                writers.add(output);
                displayNotifier(firstMessage);
                addToList();
                
                System.out.println(firstMessage.getName());

                while (socket.isConnected()) {
                    Message inputmsg = (Message) input.readObject();
                    if (inputmsg != null) {
                        
                        switch (inputmsg.getType()) {
                            case REGISTER:
                                registerUser(inputmsg);
                                break;
                            case AUTHENTICATE:
                                authenticateUser();
                                break;
                            case USER:
                                write(inputmsg);
                                break;
                            case VOICE:
                                write(inputmsg);
                                break;
                            case CONNECTED:
                                addToList();
                                break;
                            case STATUS:
                                changeStatus(inputmsg);
                                break;
                            case DISCONNECTED:
                                endUserSession(inputmsg);
                                break;
                        }
                    }
                }
            
                
            } catch (Exception ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
//                try {
//                    ois.close();
//                } catch (Exception ex) {
//                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
//                }
            }
        }

         private synchronized void  checkConnecedIP(Message newMessage) throws Exception {
             name = newMessage.getName();
            if(!names.containsKey(name) /*&& !connected_ips.contains(newMessage.getIp())*/){
                user = new User();
                user.setIP(newMessage.getIp());
                user.setName(newMessage.getName());
                user.setPicture(newMessage.getPicture());
                user.setStatus(Status.ONLINE);
                online_users.add(user);
                names.put(name, user);
            } else {
                throw new Exception("User with IP "+newMessage.getIp()+" is connected already");
            }
        }

         private void write(Message msg) throws IOException {
            for (ObjectOutputStream writer : writers) {
                msg.setUserlist(names);
                msg.setUsers(online_users);
                msg.setOnlineCount(names.size());
//                logger.info(writer.toString() + " " + msg.getName() + " " + msg.getUserlist().toString());  
                try {
                    writer.writeObject(msg);
                    writer.reset();
                } catch (Exception ex) {
                    endUserSession();
                }
            }
        }
         
         
        private Message displayNotifier(Message firstMessage) throws IOException {
            Message msg = new Message();
            msg.setMsg("has joined the chat.");
            msg.setType(MessageType.NOTIFICATION);
            msg.setName(firstMessage.getName());
            msg.setPicture(firstMessage.getPicture());
            write(msg);
            return msg;
        }

        private Message addToList() throws IOException{
            Message msg = new Message();
            msg.setMsg("Welcome to WorkTalk");
            msg.setType(MessageType.CONNECTED);
            msg.setName("SERVER");
            write(msg);
            return msg;
        }

        private synchronized void endUserSession(Message m)  {
            
            names.remove(m.getName());
              
            for (User u : online_users) {   
                if(u.getName().equals(m.getName())){
                    online_users.remove(u);
                    break;
                }
            }
            try {
                removeFromList(m.getName());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        private synchronized void endUserSession()  {
            if (name != null) {
                names.remove(name);
            }
            if (user != null){
                online_users.remove(user);
            }
            try {
                removeFromList();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private Message changeStatus(Message inputmsg) throws IOException {
            Message msg = new Message();
            msg.setName(user.getName());
            msg.setType(MessageType.STATUS);
            msg.setMsg("");
            User userObj = names.get(name);
            userObj.setStatus(inputmsg.getStatus());
            write(msg);
            return msg;
        }

        private Message removeFromList() throws IOException {
            Message msg = new Message();
            msg.setMsg("has left the chat.");
            msg.setType(MessageType.DISCONNECTED);
            msg.setName("SERVER");
            msg.setUserlist(names);
            write(msg);
            return msg;
        }
        
        private Message removeFromList(String name) throws IOException {
            Message msg = new Message();
            msg.setMsg(name+" has left the chat.");
            msg.setType(MessageType.DISCONNECTED);
            msg.setName("SERVER");
            msg.setUserlist(names);
            write(msg);
            return msg;
        }
        
        private void sendUserList(){
            
        }
        
        public void closeSocket(){
            try {
                if(socket.isConnected()){
                socket.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        private void registerUser(Message msg) throws SQLException {
            String fname = msg.getRegisterDetails().get("f_name");
            String lname = msg.getRegisterDetails().get("l_name");
            String username = msg.getRegisterDetails().get("username");
            String password = msg.getRegisterDetails().get("passsword");
            
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:server.db");
                c.setAutoCommit(false);
                stmt = c.createStatement(); 
                String sql = "INSERT INTO USERS (FNAME,LNAME,USERNAME,PASSWORD) VALUES ("+fname+","+lname+","+username+","+password+");";
                int affected = stmt.executeUpdate(sql);
                if(affected > 0){
                isRegOk = true;
                }
                stmt.close();
                c.commit();
               
            }   catch (Exception ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }  finally{
                c.close();
                Message newMsg = new Message();
                newMsg.setRegisterSuccess(isRegOk);
                try {
                    write(newMsg);
                } catch (IOException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        private void authenticateUser() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
        
    }
    
}
