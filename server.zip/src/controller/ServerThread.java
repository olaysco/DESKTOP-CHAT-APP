/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import interfaces.Message;
import interfaces.MessageType;
import static interfaces.MessageType.AUTHENTICATE;
import static interfaces.MessageType.REGISTER;
import interfaces.Status;
import static interfaces.Status.ONLINE;
import interfaces.User;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DbConnect;



/**
 *
 * @author olayiwola
 * @param <E>
 */
public class ServerThread<E extends Socket> implements Runnable{

    E socket;
    private  boolean isOn = false; 
    private static final HashMap<String, User> usernames = new HashMap<>();
    private static HashSet<ObjectOutputStream> writers = new HashSet<>();
    private static HashMap<String, ObjectOutputStream> usersWriter = new HashMap<>();
    private static ArrayList<User> online_users = new ArrayList<>();
    private static ArrayList<InetAddress> connected_ips = new ArrayList<>();
    Connection c;
    Statement stmt;
    Boolean isRegOk = false;
    Boolean isLogOk = false;
    
    String username = null;
    User user = null;
    
    @Override
    public void run() {
        clientMsgRouter();
    }
    
    public ServerThread(E socket){
        this .socket = socket;
    }
    
    private void clientMsgRouter() {
        
        ObjectInputStream input = null;
        try {
            System.out.println("Client connected");
            System.out.println("local address "+socket.getLocalAddress());
            input = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            Message firstMessage = (Message)input.readObject();
//            Message msg = new Message();
//            msg.setOnlineCount(4);
//            output.writeObject(msg);
//            System.out.println(firstMessage.getName());
            if(firstMessage.getType().equals(REGISTER)){
                registerUser(firstMessage, output);
                System.out.println("You registering");
            }else if(firstMessage.getType().equals(AUTHENTICATE)){
                authenticateUser(firstMessage, output);
                System.out.println("You logging in");
            }
            else{
                writers.add(output);
                usersWriter.put(firstMessage.getUsername(), output);
                checkConnecedIP(firstMessage);
//                displayNotifier(firstMessage);
                System.out.println("You performing other operations");
            }
            
            while (socket.isConnected()) {
            try{   
            Message inputmsg = (Message) input.readObject();
            if (inputmsg != null) {

                switch (inputmsg.getType()) {
                    case USER:
                        writeToAUser(inputmsg);
                        System.out.println(inputmsg.getUsername()+ "sending "+inputmsg.getMsg()+" to "+inputmsg.getDestination());
                        break;
                    case VOICE:
                        write(inputmsg);
                        break;
                    case CONNECTED:
                        addToList();
                        break;
                    case DISCONNECTED:
                        disconnectUser(inputmsg);
                        break;
                    case STATUS:
                        changeStatus(inputmsg);
                        break;
                    case REGISTER:
                        registerUser(inputmsg, output);
                        break;
                    case AUTHENTICATE:
                        authenticateUser(inputmsg, output);
                        break;
                }
            }
             } catch(EOFException er){
                 
             }
             
        }
        } catch (Exception  ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                input.close();
            } catch (IOException ex) {
                Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    private synchronized void  checkConnecedIP(Message newMessage) throws Exception {
             username = newMessage.getUsername();
            if(!usernames.containsKey(username) && !connected_ips.contains(newMessage.getIp())){
                user = new User();
                user.setIP(newMessage.getIp());
                user.setName(newMessage.getName());
                user.setPicture(newMessage.getPicture());
                user.setUsername(newMessage.getUsername());
                user.setStatus(ONLINE);
                online_users.add(user);
                usernames.put(username, user);
                addToList();
            } else {
                throw new Exception("User with IP "+newMessage.getIp()+" is connected already");
            }
    }
    
    private synchronized void  disconnectUser(Message newMessage) throws Exception {
             username = newMessage.getUsername();
            if(usernames.containsKey(username) ){
                online_users.removeIf((User us)->{return us.getUsername().equals(username);});
                usernames.remove(username);
                usersWriter.remove(username);
                removeFromList();
            } else {
                throw new Exception("User with IP "+newMessage.getUsername()+" does not exist");
            }
    }
    
    private Message displayNotifier(Message firstMessage) throws IOException {
        Message msg = new Message();
        msg.setMsg("has joined the chat.");
        msg.setType(MessageType.NOTIFICATION);
        msg.setName(firstMessage.getName());
        msg.setPicture(firstMessage.getPicture());
        write(msg);
        return msg;
    }
    
    private void write(Message msg) throws IOException {
        System.out.println("am about to write ");
        for (ObjectOutputStream writer : usersWriter.values()) {
            msg.setUserlist(usernames);
            msg.setUsers(online_users);
            msg.setOnlineCount(usernames.size()); 
            try {
                writer.writeObject(msg);
                writer.reset();
            } catch (Exception ex) {
                //endUserSession();
                System.out.println("Error "+ex.getMessage()+" "+ex.getCause());
            }finally{
                writer.flush();
            }
        }
    }
    
    private void writeToAUser(Message msg) throws IOException{
        ObjectOutputStream output = usersWriter.get(msg.getDestination());
        try { 
            output.writeObject(msg);
            System.out.println("sent");
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            output.flush();
        }
    }
    
    private void writeToSender(Message msg, ObjectOutputStream output) throws IOException {
        try { 
            output.writeObject(msg);
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            output.flush();
        }
    }
        
    
    
    private Message removeFromList() throws IOException {
        Message msg = new Message();
        msg.setMsg("has left the chat.");
        msg.setType(MessageType.DISCONNECTED);
        msg.setName("SERVER");
        msg.setUserlist(usernames);
        msg.setUsers(online_users);
        write(msg);
        return msg;
    }
    
    private Message addToList() throws IOException{
        Message msg = new Message();
        msg.setMsg("Welcome to WorkTalk");
        msg.setType(MessageType.CONNECTED);
        msg.setName("SERVER");
        msg.setStatus(ONLINE);
        System.out.println("am in add to list ");
        write(msg);
        return msg;
    }
    
    private Message changeStatus(Message inputmsg) throws IOException {
//          logger.debug(inputmsg.getName() + " has changed status to  " + inputmsg.getStatus());
            Message msg = new Message();
            msg.setName(user.getName());
            msg.setType(MessageType.STATUS);
            msg.setMsg("");
            User userObj = usernames.get(username);
            userObj.setStatus(inputmsg.getStatus());
            write(msg);
            return msg;
    }
    private void registerUser(Message msg, ObjectOutputStream output) throws SQLException, IOException {
        String fname = msg.getRegisterDetails().get("f_name");
        String lname = msg.getRegisterDetails().get("l_name");
        String username = msg.getRegisterDetails().get("username");
        String password = msg.getRegisterDetails().get("password");
        Message newMsg = new Message();
        DbConnect db = new DbConnect();
        newMsg = db.register(username, password, fname, lname);
        writeToSender(newMsg, output); 
        socket.close();
        Thread.currentThread().interrupt();
            
    }

    private void authenticateUser(Message msg, ObjectOutputStream output) throws Exception {
        String username = msg.getLoginDetails().get("username");
        String password = msg.getLoginDetails().get("password");
        Message newMsg = null;
        if(!usernames.containsKey(username)){
        System.out.println(username +"\n"+ password);
        newMsg = new Message();
        DbConnect db = new DbConnect();
        newMsg = db.login(username, password);
        }
        else{
            newMsg.setMsg("user already login");
            newMsg.setName("");
            newMsg.setLoginSuccess(false);
        }
        writeToSender(newMsg, output);
        socket.close();
        Thread.currentThread().interrupt();
    }
}
    
