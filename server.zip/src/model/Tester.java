/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import interfaces.Status;
import static interfaces.Status.ONLINE;

/**
 *
 * @author olayiwola
 */
public class Tester {
    
    
    public static void main(String args[]){
        Status stat;
        
        
        stat = ONLINE;
        String word = "my status is "+stat;
        System.out.println(word);
        
        
    }

    

    
}
