/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import interfaces.Message;
import java.sql.*;


/**
 *
 * @author olayiwola
 */
public class DbConnect {
    
    Connection c = null;
    Statement stmt = null;
    public DbConnect() {
        
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:server.db");
            stmt = c.createStatement();
            String sql = "CREATE TABLE USERS " +
            "(FNAME TEXT NOT NULL, " +
            " LNAME TEXT NOT NULL, " +        
            " USERNAME TEXT NOT NULL, " +
            " PASSWORD CHAR(50))";
            stmt.executeUpdate(sql);
            stmt.close();
            c.close();
        } catch (ClassNotFoundException | SQLException e ) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage() );
        }
        System .out.println("Opened database successfully");
    }
    
    public Message login(String username, String password) throws SQLException{
        
        Boolean isLogOk = false;
        String info = "";
        String fname = "";
        String lname = "";
        Message newMsg = new Message();
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:server.db");
            stmt = c.createStatement(); 
            String sql = "SELECT * FROM USERS WHERE USERNAME LIKE '"+username+"' AND PASSWORD LIKE '"+password+"'";
            ResultSet rs = stmt.executeQuery(sql); 
            if(rs.next()){
                isLogOk = true;
                info = "Authentication Successful";
                fname = rs.getString("fname");
                lname = rs.getString("lname");
               
            }else{
                info = "Authentication failure";
            }
            
            stmt.close();

        }   catch (Exception ex) {
            System.out.println(ex.getMessage());
            info = "A Database processing occured";
        }  finally{
            c.close();
            newMsg.setMsg(info);
            newMsg.setName(fname+" "+lname);
            newMsg.setLoginSuccess(isLogOk);
        }
        
        return newMsg;
    }
    
    public Message register(String username, String password, String fname, String lname) throws SQLException{
        int affected = 0;
        boolean isRegOk = false;
        String info = "";
        Message newMsg = new Message();
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:server.db");
                c.setAutoCommit(false);
                stmt = c.createStatement();
                String sql = "SELECT * FROM USERS WHERE USERNAME = '"+username+"'";
                ResultSet rs = stmt.executeQuery(sql);
                if(!rs.next()){
                    sql = "INSERT INTO USERS (FNAME,LNAME,USERNAME,PASSWORD) VALUES ('"+fname+"','"+lname+"','"+username+"','"+password+"');";
                     affected = stmt.executeUpdate(sql);
                     if(affected > 0){
                        isRegOk = true;
                        info = "Successfully registered";
                    }else{
                         info = "An error occured";
                    }
                }else{
                    info = "user already exist";
                }
                stmt.close();
                c.commit(); 
            }   catch (Exception ex) {
                    System.out.println(ex.getMessage());
                    info = "Database processing error";
            }  finally{
                c.close();
                newMsg.setMsg(info);
                newMsg.setRegisterSuccess(isRegOk); 
            }
            
            return newMsg;
    }
}
