/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author olayiwola
 */
public class DbOPeration {
    public static void main( String args[] ){
    Connection c = null;
    Statement stmt = null;
    int affected = 0;
    try {
        Class.forName("org.sqlite.JDBC");
        c = DriverManager.getConnection("jdbc:sqlite:server.db");
        c.setAutoCommit(true);
        System .out.println("Opened database successfully");
        stmt = c.createStatement();
        String fname = "lolll";
        String lname = "fer";
        String password = "nadoo";
        String username = "hunk";
//        String sql = "INSERT INTO USERS (FNAME,LNAME,USERNAME,PASSWORD) VALUES ('"+fname+"','"+lname+"','"+username+"','"+password+"');";
//        affected = stmt.executeUpdate(sql);
//        sql = "INSERT INTO USERS (FNAME,LNAME,USERNAME,PASSWORD) VALUES ('kla', 'lok', 'sap', 'oli');";
//        affected = stmt.executeUpdate(sql);
//        sql = "INSERT INTO USERS (FNAME,LNAME,USERNAME,PASSWORD) VALUES ('kols', 'lop', 'poll', 'leo');";
//        affected = stmt.executeUpdate(sql);
//        sql = "INSERT INTO USERS (FNAME,LNAME,USERNAME,PASSWORD) VALUES ('juki', 'ikll', 'goli', 'hulo');";
//        affected = stmt.executeUpdate(sql);
//        String sql = "UPDATE USERS SET PASSWORD = 'riliwan' WHERE USERNAME LIKE 'olay';";
//        affected = stmt.executeUpdate(sql);
        
        String sql = "SELECT * FROM USERS WHERE USERNAME LIKE '"+username+"' AND PASSWORD LIKE '"+password+"'";
        ResultSet rs = stmt.executeQuery(sql); 
        if ( rs.next() ) {
            fname = rs.getString("fname");
            lname = rs.getString("lname");
            username = rs.getString("username");
            password = rs.getString("password");
            
            System.out.println( "FNAME = " + fname );
            System.out.println( "LNAME = " + lname );
            System.out.println( "USERNAME = " + username );
            System.out.println( "PASSWORD = " + password);
            System.out.println();
        }
        
        rs.close();
    stmt.close();
    c.close();
    } catch ( Exception e ) {
        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
    } finally{
////        if(affected > 0){
////            System.out.println("Successfully registered");
////        }else{
////            System.out.println("An error occured");
////        }
    }
    
    }
    
}
